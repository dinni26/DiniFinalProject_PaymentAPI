using FinalProject.Configuration;

namespace FinalProject.Models.DTOs.Responses{
    public class RegistrationResponse: AuthResult{
        
    }
}